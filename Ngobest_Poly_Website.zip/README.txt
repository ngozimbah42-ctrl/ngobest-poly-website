NGOBEST POLY WEBSITE
====================

FILES
- index.html: The complete website in one file. HTML, CSS, and JavaScript are included together.

HOW TO PREVIEW ON YOUR PHONE
1. Download the ZIP and extract it, or download index.html directly.
2. Open index.html using a browser (Chrome is fine). Some phones may require a file manager to open it.
3. The pictures are loaded from Unsplash, so internet access is needed to display them.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES
1. On your phone, open https://github.com/ and create/sign in to an account.
2. Create a new repository named ngobest-poly-website. Set it to Public.
3. Choose Add file > Upload files and upload index.html from this package.
4. Commit the uploaded file.
5. Open the repository Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select the main branch and /(root), then Save.
8. Wait a few minutes. GitHub will show your public website URL in Settings > Pages.

OTHER FREE OPTION
You can also use https://www.netlify.com/ and deploy the extracted website folder using Netlify's manual deploy instructions. If using a phone, GitHub Pages may be easier when uploading the single index.html file.

IMPORTANT
- The WhatsApp buttons are connected to the Nigerian number supplied by you (08162250979).
- The contact form prepares a WhatsApp message; it does not save submissions to a database.
- Images are external Unsplash image links and require internet. Replace them later with your own business/factory photos for a more personal website.
- Before publishing, check that the address, phone number, email, services, and wording are correct.
